import sqlite3

con = sqlite3.connect("employee.db")
print("Database opened successfully")

con.execute(
    "create table Events (id INTEGER PRIMARY KEY AUTOINCREMENT, event TEXT NOT NULL, date TEXT UNIQUE NOT NULL, city TEXT NOT NULL, venue TEXT NOT NULL)")

print("Table created successfully")

con.close()
